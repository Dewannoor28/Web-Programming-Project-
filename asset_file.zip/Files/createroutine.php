<?php
$host="localhost";
$user="root";
$pass="";
$db="classroutine";

// Create a connection
$conn = new mysqli($host, $user, $pass, $db);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process form data if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $teachername = $_POST["teachername"];
    $coursename = $_POST["coursename"];
    $coursecode = $_POST["coursecode"];
    $batchname = $_POST["batchname"];
    $classroom = $_POST["classroom"];
    

    // Perform SQL insert query to add the data to the database
    $sql = "INSERT INTO userregistration (teachername, coursename, coursecode, batchname, classroomd) VALUES ('$firstname', '$lastname', '$email', '$department', '$password', '$cpassword')";

    if ($conn->query($sql) === TRUE) {
        echo "";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the connection
$conn->close();
?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Details</title>
  <style>
    /* Your CSS styles go here */
    body {
      font-family: Arial, sans-serif;
      text-align: center;
    }

    header {
      background-color: #b092e8;
      color: #ffffff;
      padding: 10px;
    }

    main {
      margin: 20px;
    }

    .form-section {
      background-color: #f9f9f9;
      border: 1px solid #ddd;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .form-section h2 {
      margin-bottom: 20px;
    }

    .form-section label {
      font-weight: bold;
      display: block;
    }

    .form-section input,
    .form-section select,
    .form-section button {
      margin: 10px 0;
      padding: 8px;
      border: 1px solid #ddd;
      border-radius: 5px;
      width: 100%;
      max-width: 400px;
    }

    .form-section button {
      background-color: #b092e8;
      color: #ffffff;
      cursor: pointer;
    }

    .add_button {
      display: inline-block;
      padding: 5px 10px;
      background-color: #b092e8;
      color: #ffffff;
      text-decoration: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .add_button:hover {
      background-color: #a080d8;
    }

    .next_page {
      display: inline-block;
      padding: 8px 20px;
      background-color: #b092e8;
      color: #ffffff;
      text-decoration: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .next_page:hover {
      background-color: #a080d8;
    }
    
    /* ... Rest of your CSS styles ... */
  </style>
</head>

<body>
  <header>
    <h1>Online Schedule Management</h1>
  </header>

  <main>
    <!-- Teacher Name Form Section -->
    <div class="form-section">
      <h2>Add Teacher's Details</h2>
      <form id="teacherForm">
        <label for="teacherNames">Teacher Names (comma-separated):</label>
        <input type="text" id="teacherNames" required>
      </form>
      <div id="teacherList">
        <!-- Teacher names will be displayed here -->
      </div>
    </div>

    <!-- Course Details Form Section -->
    <div class="form-section">
      <h2>Add Course Details</h2>
      <form id="courseForm" onsubmit="addCourse(event)">
        <div>
          <label for="courseCodes">Course Codes (newline-separated):</label>
          <textarea id="courseCodes" required></textarea>
        </div>

        <div>
          <label for="courseTitles">Course Titles (comma-separated):</label>
          <input type="text" id="courseTitles" required>
        </div>

3
        <div id="courseList">
          <!-- Course details will be displayed here -->
        </div>

        <!-- "Add" button to add course details -->
        <div><a href="nextpage.html" class="next_page">Add Details</a></div>
        
      </form>
    </div>
  </main>

  <script>
    // Function to add multiple teacher names at once
    function addTeachers() {
      const teacherNamesInput = document.getElementById('teacherNames');
      const teacherNamesString = teacherNamesInput.value.trim();
      if (teacherNamesString !== '') {
        const teacherNames = teacherNamesString.split('\n');
        const teacherList = document.getElementById('teacherList');
        teacherNames.forEach(name => {
          const newTeacherElement = document.createElement('p');
          newTeacherElement.textContent = name.trim();
          teacherList.appendChild(newTeacherElement);
        });
        teacherNamesInput.value = '';
      }
    }

    // Function to add course details to the array
    function addCourseDetails() {
      const courseCodesInput = document.getElementById('courseCodes');
      const courseTitlesInput = document.getElementById('courseTitles');
      const creditHourInput = document.getElementById('creditHour');
      const courseCodesString = courseCodesInput.value.trim();
      const courseTitlesString = courseTitlesInput.value.trim();
      const creditHour = parseInt(creditHourInput.value);

      if (courseCodesString !== '' && courseTitlesString !== '' && !isNaN(creditHour)) {
        const courseCodes = courseCodesString.split('\n');
        const courseTitles = courseTitlesString.split(',');
        const courseList = document.getElementById('courseList');

        if (courseCodes.length === courseTitles.length) {
          for (let i = 0; i < courseCodes.length; i++) {
            const newCourseElement = document.createElement('p');
            newCourseElement.innerHTML = `<strong>Course Code:</strong> ${courseCodes[i].trim()}<br>
                                          <strong>Course Title:</strong> ${courseTitles[i].trim()}<br>
                                          <strong>Credit/Hour:</strong> ${creditHour}`;
            courseList.appendChild(newCourseElement);
          }
        }

        courseCodesInput.value = '';
        courseTitlesInput.value = '';
        creditHourInput.value = '';
      }
    }
  </script>
</body>

</html>
