<?php
$host="localhost";
$user="root";
$pass="";
$db="classroutine";

$conn=mysqli_connect($host,$user,$pass,$db);

?>

